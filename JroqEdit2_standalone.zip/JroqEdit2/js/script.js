/**
 * JroqEdit | Nihai Uygulama Motoru
 * Mimar: Bozan Mert Balta
 * Amaç: APK Yayını Öncesi Kararlı Sürüm
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. AYARLARI SESSİZCE YÜKLE
    initGlobalSettings();

    // 2. SAYFA MOTORLARINI ÇALIŞTIR (KONSOL ÇIKTISI OLMADAN)
    const page = window.location.pathname.split("/").pop();
    if (page === "index.html" || page === "") initIndex();
    if (page === "calismaalani.html") initWorkspace();
});

function initGlobalSettings() {
    const size = localStorage.getItem('jroqFontSize') || '14';
    const font = localStorage.getItem('jroqFontFamily') || "'Inter', sans-serif";
    const theme = JSON.parse(localStorage.getItem('jroq_theme')) || {tag: '#569cd6', attr: '#9cdcfe', str: '#ce9178'};

    document.documentElement.style.setProperty('--main-font-size', size + 'px');
    document.body.style.fontFamily = font;
    
    // Kod renklerini CSS değişkenlerine mühürle
    const root = document.documentElement;
    root.style.setProperty('--tag-color', theme.tag);
    root.style.setProperty('--attr-color', theme.attr);
    root.style.setProperty('--str-color', theme.str);
}

function initIndex() {
    const container = document.getElementById('recentContainer');
    if (!container) return;
    const projects = JSON.parse(localStorage.getItem('jroqProjects') || '[]');
    if (projects.length > 0) {
        container.innerHTML = projects.slice(-5).reverse().map(p => `
            <a href="editor.html?id=${p.id}" class="file-card">
                <div class="file-icon-box"><i class="fa-solid fa-file-code"></i></div>
                <div class="file-info"><b>${p.name}</b><span>${p.date}</span></div>
            </a>
        `).join('');
    }
}

function initWorkspace() {
    const list = document.getElementById('fileList');
    if (!list) return;
    const projects = JSON.parse(localStorage.getItem('jroqProjects') || '[]');
    if (projects.length > 0) {
        list.innerHTML = projects.reverse().map(p => `
            <a href="editor.html?id=${p.id}" class="file-row">
                <div class="icon-box"><i class="fa-solid fa-file"></i></div>
                <div class="row-text"><b>${p.name}</b><span>${p.date}</span></div>
            </a>
        `).join('');
    }
}
