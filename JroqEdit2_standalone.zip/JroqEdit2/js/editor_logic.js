/* JroqEdit Pro | JS Mantık Motoru */

const area = document.getElementById('editor-core');
const ln = document.getElementById('ln');

// 1. Hızlı Kod Ekleme (Tıklanan butona göre)
function addText(val) {
    const start = area.selectionStart;
    const end = area.selectionEnd;
    const currentVal = area.value;

    // İmlecin olduğu yere kodu yapıştır
    area.value = currentVal.substring(0, start) + val + currentVal.substring(end);
    
    // İmleci yapıştırılan kodun sonuna taşı ve odaklan
    area.focus();
    area.setSelectionRange(start + val.length, start + val.length);
    
    // Satırları güncelle
    syncLines();
}

// 2. Satır Numarası Sayacı
function syncLines() {
    const lines = area.value.split('\n').length;
    let lineNumbersHTML = '';
    for (let i = 1; i <= lines; i++) {
        lineNumbersHTML += i + '<br>';
    }
    ln.innerHTML = lineNumbersHTML;
}

// 3. Kod Yürütücü (Preview)
function openPreview() {
    const code = area.value;
    if(!code) {
        alert("Mimari boş! Önce kod dök Bozan.");
        return;
    }
    
    // LocalStorage'a kaydet (Uyanış kalıcı olsun)
    localStorage.setItem('jroq_last_code', code);
    
    alert("JroqEdit: Sistem ayağa kaldırılıyor... Kodlar derlendi.");
    // Burada iframe veya yeni sekme açma mantığı eklenebilir
}

// Alan değiştiğinde satırları saymaya devam et
area.addEventListener('input', syncLines);
