# ======================================================
# JroqEdit | MERKEZİ SİSTEM YÖNETİM BİRİMİ
# Mimar: Bozan Mert Balta
# Görev: Tüm HTML Odalarını ve Sistem Bütünlüğünü Yönetmek
# ======================================================

import os

class JroqMaster:
    def __init__(self):
        self.mimar = "Bozan Mert Balta"
        self.surum = "1.0.1"
        self.moduller = [
            "index.html", "editor.html", "calismaalani.html", 
            "python_projelerim.html", "sil.html", "yuklenme.html"
        ]

    def sistem_analizi(self):
        print(f"--- JroqEdit {self.surum} Yükleniyor ---")
        print(f"Yetkili Mimar: {self.mimar}")
        print("-" * 30)
        
        # HTML Odalarını Tara
        mevcut_odalar = 0
        for oda in self.moduller:
            if os.path.exists(oda):
                print(f"[ONAY] {oda} odası mühürlendi.")
                mevcut_odalar += 1
            else:
                print(f"[HATA] {oda} odası kayıp! Mimar müdahalesi gerek.")
        
        print("-" * 30)
        print(f"Sistem Durumu: %{int((mevcut_odalar/len(self.moduller))*100)} Hazır")
        if mevcut_odalar == len(self.moduller):
            print("MESAJ: Tüm HTML kalesi savunmaya ve kodlamaya hazır! 🦾")

# --- MOTORU ATEŞLE ---
if __name__ == "__main__":
    jroq = JroqMaster()
    jroq.sistem_analizi()
